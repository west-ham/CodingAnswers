Post the codes in C++!!
